<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Шапка с каталогом товаров</title>
  <link rel="stylesheet" href="../boots/bootstrap.css">
  <link rel="stylesheet" href="style/style.css">
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-light">
    <a class="navbar-brand" href="#">Music House</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link" href="../index.php">Главная</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../about/index.php">О нас</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Каталог</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Где нас найти</a>
        </li>
        <?php
    session_start();
    if (isset($_SESSION['is_logged_in']) && $_SESSION['is_logged_in']) {
        // Если пользователь авторизован, отобразить ссылку на выход (logout.php)
        echo '<li class="nav-item">
                <a class="nav-link" href="../logout.php">Выход</a>
              </li>';
    } else {
        // Если пользователь не авторизован, отобразить ссылки на регистрацию и авторизацию
        echo '<li class="nav-item">
                <a class="nav-link" href="../registr/index.php">Регистрация</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../registr/auth.php">Авторизация</a>
              </li>';
    }
    ?>
      </ul>
    </div>
  </nav>
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <img src="../images/6.jpeg" alt="Product Image" class="img-fluid">
        </div>
        <div class="col-md-8">
            <h1>Гитара</h1>
            <h4>Цена: 5000р.</h4>
            <h5>Характеристики:Мощная гитара</h5>
            <ul>
                <li>Страна-производитель: Россия</li>
                <li>Вид товара: Музыка</li>
                <li>Цвет: Желтый</li>
            </ul>
        </div>
    </div>
</div>



</body>
</html>
