<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Авторизация</title>
  <link rel="stylesheet" href="../boots/bootstrap.css?v=1">
  <link rel="stylesheet" href="style/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="#">Music House</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="../index.php">Главная</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../about/index.php">О нас</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../catalog/index.php">Каталог</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Где нас найти</a>
            </li>
            <?php
    session_start();
    if (isset($_SESSION['is_logged_in']) && $_SESSION['is_logged_in']) {
        // Если пользователь авторизован, отобразить ссылку на выход (logout.php)
        echo '<li class="nav-item">
                <a class="nav-link" href="logout.php">Выход</a>
              </li>';
    } else {
        // Если пользователь не авторизован, отобразить ссылки на регистрацию и авторизацию
        echo '<li class="nav-item">
                <a class="nav-link" href="/registr/index.php">Регистрация</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Авторизация</a>
              </li>';
    }
    ?>
    </ul>
        </div>
      </nav>
  <div class="container">
    <h1>Авторизация</h1>
    <form id="login-form" method="post" action="login.php">
      <div class="form-group">
        <label for="login">Логин</label>
        <input type="text" class="form-control" id="login" name="login" required>
        <label for="password">Пароль</label>
        <input type="password" class="form-control" id="password" name="password" required>
      </div>
      <button type="submit" class="btn btn-primary" name="submit">Войти</button>
    </form>
  </div>
</body>
</html>
