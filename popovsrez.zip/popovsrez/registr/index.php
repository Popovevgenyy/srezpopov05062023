<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Регистрация нового пользователя</title>
  <link rel="stylesheet" href="../boots/bootstrap.css?v=1">
  <link rel="stylesheet" href="style/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="#">Music House</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="../index.php">Главная</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../about/index.php">О нас</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../catalog/index.php">Каталог</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Где нас найти</a>
            </li>
            <?php
    session_start();
    if (isset($_SESSION['is_logged_in']) && $_SESSION['is_logged_in']) {
        // Если пользователь авторизован, отобразить ссылку на выход (logout.php)
        echo '<li class="nav-item">
                <a class="nav-link" href="logout.php">Выход</a>
              </li>';
    } else {
        // Если пользователь не авторизован, отобразить ссылки на регистрацию и авторизацию
        echo '<li class="nav-item">
                <a class="nav-link" href="#">Регистрация</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="auth.php">Авторизация</a>
              </li>';
    }
    ?>
      
          </ul>
        </div>
      </nav>


  <div class="container">
    <h1>Регистрация нового пользователя</h1>
    <form id="registration-form" method="post" action="register.php">
      <div class="form-group">
        <label for="name">Имя</label>
        <input type="text" class="form-control" id="name" name="name" required pattern="[а-яА-ЯёЁ\s-]+">
      </div>
      <div class="form-group">
        <label for="surname">Фамилия</label>
        <input type="text" class="form-control" id="surname" name="surname" required pattern="[а-яА-ЯёЁ\s-]+">
      </div>
      <div class="form-group">
        <label for="patronymic">Отчество</label>
        <input type="text" class="form-control" id="patronymic" name="patronymic" pattern="[а-яА-ЯёЁ\s-]+">
      </div>
      <div class="form-group">
        <label for="login">Логин</label>
        <input type="text" class="form-control" id="login" name="login" required pattern="[a-zA-Z0-9-]+">
      </div>
      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" class="form-control" id="email" name="email" required>
      </div>
      <div class="form-group">
        <label for="password">Пароль</label>
        <input type="password" class="form-control" id="password" name="password" required minlength="6">
      </div>
      <div class="form-group">
        <label for="password_repeat">Повторите пароль</label>
        <input type="password" class="form-control" id="password_repeat" name="password_repeat" required>
      </div>
      <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="rules" name="rules" required>
        <label class="form-check-label" for="rules">Согласие с правилами регистрации</label>
      </div>
      <button type="submit" class="btn btn-primary" name="register">Зарегистрироваться</button>
    </form>

<script>
    $(document).ready(function() {
      $('#registration-form').validate({
        rules: {
          // Правила валидации
        },
        messages: {
          // Сообщения об ошибках
        },
        submitHandler: function(form) {
          form.submit();
        }
      });
    });
  </script>
</body>
</html>
