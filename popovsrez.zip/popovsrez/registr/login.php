<?php
// Подключение к базе данных MySQL
$host = 'localhost'; // Адрес сервера базы данных
$db = 'konsovka'; // Имя базы данных
$user = 'root'; // Имя пользователя базы данных
$password = ''; // Пароль пользователя базы данных

$connection = mysqli_connect($host, $user, $password, $db);
if (!$connection) {
    die('Ошибка подключения к базе данных: ' . mysqli_connect_error());
}

// Функция для защиты данных от SQL-инъекций
function escape($value) {
    global $connection;
    return mysqli_real_escape_string($connection, $value);
}

// Обработка запроса на авторизацию
if (isset($_POST['submit'])) {
    $login = escape($_POST['login']);
    $password = escape($_POST['password']);
    
    // Поиск пользователя по логину
    $selectQuery = "SELECT * FROM users WHERE login='$login'";
    $selectResult = mysqli_query($connection, $selectQuery);
    
    if (mysqli_num_rows($selectResult) > 0) {
        $user = mysqli_fetch_assoc($selectResult);
        
        // Проверка введенного пароля
        if (password_verify($password, $user['password'])) {
            // Авторизация успешна
            echo 'Авторизация успешна';
            session_start();
$_SESSION['is_logged_in'] = true;
            // Редирект на главную страницу
            header('Location: ../index.php');
            exit();
        } else {
            echo 'Неверный логин или пароль';
        }
    } else {
        echo 'Неверный логин или пароль';
    }
}

// Закрытие соединения с базой данных
mysqli_close($connection);
?>
