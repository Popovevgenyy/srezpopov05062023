<?php
// Подключение к базе данных MySQL
$host = 'localhost'; // Адрес сервера базы данных
$db = 'konsovka'; // Имя базы данных
$user = 'root'; // Имя пользователя базы данных
$password = ''; // Пароль пользователя базы данных

$connection = mysqli_connect($host, $user, $password, $db);
if (!$connection) {
    die('Ошибка подключения к базе данных: ' . mysqli_connect_error());
}

// Функция для защиты данных от SQL-инъекций
function escape($value) {
    global $connection;
    return mysqli_real_escape_string($connection, $value);
}

// Обработка запроса на регистрацию
if (isset($_POST['register'])) {
    $name = escape($_POST['name']);
    $surname = escape($_POST['surname']);
    $patronymic = escape($_POST['patronymic']);
    $login = escape($_POST['login']);
    $email = escape($_POST['email']);
    $password = escape($_POST['password']);
    
    // Проверка наличия пользователя с таким же логином или email в базе данных
    $checkQuery = "SELECT * FROM users WHERE login='$login' OR email='$email'";
    $checkResult = mysqli_query($connection, $checkQuery);
    
    if (mysqli_num_rows($checkResult) > 0) {
        echo 'Пользователь с таким логином или email уже существует';
    } else {
        // Хэширование пароля
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        // Вставка данных нового пользователя в базу данных
        $insertQuery = "INSERT INTO users (name, surname, patronymic, login, email, password) VALUES ('$name', '$surname', '$patronymic', '$login', '$email', '$hashedPassword')";
        $insertResult = mysqli_query($connection, $insertQuery);
        
        if ($insertResult) {
            // Регистрация прошла успешно
            header('Location: ../index.php'); // Перенаправление на главный экран
            exit(); // Остановка выполнения скрипта после перенаправления
        } else {
            echo 'Ошибка регистрации: ' . mysqli_error($connection);
        }
    }
}

// Закрытие соединения с базой данных
mysqli_close($connection);
?>
