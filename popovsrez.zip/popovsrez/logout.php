<?php
// Инициализируем сессию
session_start();

// Удаляем все данные сессии
session_unset();

// Уничтожаем сессию
session_destroy();

// Перенаправляем пользователя на страницу авторизации
header("Location: registr/auth.php");
exit();
?>