<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Шапка с каталогом товаров</title>
  <link rel="stylesheet" href="../boots/bootstrap.css">
  <link rel="stylesheet" href="style/style.css">
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-light">
    <a class="navbar-brand" href="#">Music House</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link" href="../index.php">Главная</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../about/index.php">О нас</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Каталог</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Где нас найти</a>
        </li>
        <?php
    session_start();
    if (isset($_SESSION['is_logged_in']) && $_SESSION['is_logged_in']) {
        // Если пользователь авторизован, отобразить ссылку на выход (logout.php)
        echo '<li class="nav-item">
                <a class="nav-link" href="../logout.php">Выход</a>
              </li>';
    } else {
        // Если пользователь не авторизован, отобразить ссылки на регистрацию и авторизацию
        echo '<li class="nav-item">
                <a class="nav-link" href="../registr/index.php">Регистрация</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../registr/auth.php">Авторизация</a>
              </li>';
    }
    ?>
      </ul>
    </div>
  </nav>

  <div class="container">
    <h1>Каталог товаров</h1>
    <div class="row" id="product-row1">
      <div class="col-md-4">
        <div class="card">
          <img src="../images/6.jpeg" alt="альтернативный текст" />
          <div class="card-body">
            <h5 class="card-title">Гитара</h5>
            <p class="card-text">5000р.</p>
            <a href="../tovars/product1.php" class="btn btn-primary" style="color: black; background-color: white;">К товару</a>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <img src="../images/7.png" alt="э" />
          <div class="card-body">
            <h5 class="card-title">Пианино</h5>
            <p class="card-text">5555р.</p>
            <a href="../tovars/product2.php" class="btn btn-primary" style="color: black; background-color: white;">К товару</a>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <img src="../images/foniz1.jpeg" alt="альтернативный текст" />
          <div class="card-body">
            <h5 class="card-title">Крутая гитара</h5>
            <p class="card-text">8888р.</p>
            <a href="../tovars/product3.php" class="btn btn-primary" style="color: black; background-color: white;">К товару</a>
          </div>
        </div>
      </div>
    </div>
    <div class="row" id="product-row2">
        <div class="col-md-4">
          <div class="card">
            <img src="../images/8.png" alt="альтернативный текст" />
            <div class="card-body">
              <h5 class="card-title">Крутое пианино</h5>
              <p class="card-text">6666р.</p>
              <a href="../tovars/product4.php" class="btn btn-primary" style="color: black; background-color: white;">К товару</a>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card">
            <img src="../images/2.jpeg" alt="альтернативный текст" />
            <div class="card-body">
              <h5 class="card-title">Электро-пианино</h5>
              <p class="card-text">7777р.</p>
              <a href="product5.html" class="btn btn-primary" style="color: black; background-color: white;">К товару</a>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card">
            <img src="../images/5.jpeg" alt="альтернативный текст" />
            <div class="card-body">
              <h5 class="card-title">Электро-гитара</h5>
              <p class="card-text">9999р.</p>
              <a href="product6.html" class="btn btn-primary" style="color: black; background-color: white;">К товару</a>
            </div>
          </div>
        </div>
      </div>
    <div class="row">
      <div class="col-md-12">
        <button class="btn btn-primary sort-button" onclick="sortCatalog()">Сортировать по названию</button>
        <button class="btn btn-primary reset-button" onclick="resetCatalog()">Сбросить сортировку</button>
      </div>
    </div>
  </div>  
  <script>
   var originalOrder1 = [];
var originalOrder2 = [];

// Запоминаем исходный порядок карточек при загрузке страницы
window.onload = function() {
  var row1 = document.getElementById('product-row1');
  originalOrder1 = Array.from(row1.children);
  var row2 = document.getElementById('product-row2');
  originalOrder2 = Array.from(row2.children);
};

function sortCatalog() {
  var row1 = document.getElementById('product-row1');
  var row2 = document.getElementById('product-row2');

  // Преобразовываем HTMLCollection в массив для удобства сортировки
  var cardsArray1 = Array.from(row1.children);
  var cardsArray2 = Array.from(row2.children);

  // Сортируем массивы по названию товара
  cardsArray1.sort(function(a, b) {
    var titleA = a.querySelector('.card-title').innerText;
    var titleB = b.querySelector('.card-title').innerText;
    return titleA.localeCompare(titleB);
  });

  cardsArray2.sort(function(a, b) {
    var titleA = a.querySelector('.card-title').innerText;
    var titleB = b.querySelector('.card-title').innerText;
    return titleA.localeCompare(titleB);
  });

  // Переупорядочиваем карточки товаров в родительских элементах
  cardsArray1.forEach(function(card) {
    row1.appendChild(card);
  });

  cardsArray2.forEach(function(card) {
    row2.appendChild(card);
  });
}

function resetCatalog() {
  var row1 = document.getElementById('product-row1');
  var row2 = document.getElementById('product-row2');

  // Восстанавливаем исходный порядок карточек товаров
  originalOrder1.forEach(function(card) {
    row1.appendChild(card);
  });

  originalOrder2.forEach(function(card) {
    row2.appendChild(card);
  });
}
  </script>
</body>
</html>
