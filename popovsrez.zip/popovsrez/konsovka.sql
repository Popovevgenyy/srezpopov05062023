-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июн 05 2023 г., 11:20
-- Версия сервера: 8.0.30
-- Версия PHP: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `konsovka`
--

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `patronymic` varchar(255) DEFAULT NULL,
  `login` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `surname`, `patronymic`, `login`, `email`, `password`) VALUES
(1, 'Евгений', 'Попов', 'Пантелеймонович', 'mimima', 'mimima@gmail.com', '$2y$10$1VSELNp7/YdLLcxU1s43O.5JXnIM65UAWKLlQugOVXX1G72u2ISZm'),
(2, 'Евгений', 'Попов', 'Пантелеймонович', 'Admin', 'admin@gmail.com', '$2y$10$WlH355SPez66LfyscTWEE.LCe0ijnADp8MKgPBs2UtmB13PwxNWlC'),
(3, 'фывапппп', 'фываппп', 'фывапп', 'adminik', 'adminik@gmail.com', '$2y$10$DdPxXWHS2J08v7Kp.k2Vve4GhnpB5YP9SHHJajyKnybixRmi.6LL6'),
(4, 'року', 'фывр', 'фыар', 'adminiks', 'adminiks@gmail.com', '$2y$10$D6V2bwcjPhbAy.Ik.tO0ueZ8sU8k3olxTaHSNlr9W2DKV0ZOKgPc.'),
(5, 'лщзплщп', 'овкеовеко', 'вокеовке', 'mihan', 'mihan@gmail.com', '$2y$10$BnuO21QUhVCLmKbhEiuBteod40yBy5T0YslZ93qYfUUL307unmzSS'),
(6, 'Евгенийы', 'пфывпрывф', 'рфывр', 'loginik', 'loginik@gmail.com', '$2y$10$BshU4a82nzUbuUKOdvnUU.IsazLB6iqtS3MXgg3DWSwmgeCC1ftb6'),
(7, 'Анатолий', 'Иванов', 'Дмитриевич', 'alexander', 'alexander@gmail.com', '$2y$10$yA1vQ2qGSaSyQYESDd5FheT8VUe7kO9R1ID8OPWmLdNwmyisJ1bTC'),
(8, 'Иван', 'Иванов', 'Иванович', 'dimka1', 'dimka1@gmail.com', '$2y$10$Fc9DKb1M84CxJYUrzO0iyO6Jhwbq27JN5r.jNCt.3e98xaEGtPfVa');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
