<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="boots/bootstrap.css?v=1">
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
    <script src="js/bootstrap.js"></script>

    
    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="#">Music House</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#">Главная</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about/index.php">О нас</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="catalog/index.php">Каталог</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Где нас найти</a>
            </li>
            <?php
    session_start();
    if (isset($_SESSION['is_logged_in']) && $_SESSION['is_logged_in']) {
        // Если пользователь авторизован, отобразить ссылку на выход (logout.php)
        echo '<li class="nav-item">
                <a class="nav-link" href="logout.php">Выход</a>
              </li>';
    } else {
        // Если пользователь не авторизован, отобразить ссылки на регистрацию и авторизацию
        echo '<li class="nav-item">
                <a class="nav-link" href="/registr/index.php">Регистрация</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="registr/auth.php">Авторизация</a>
              </li>';
    }
    ?>
    
              
          </ul>
        </div>
      </nav>

      <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2" aria-label="Slide 3" ></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="images/2.jpeg" alt="" class="d-block w-100 h-100">
            <div class="container">
              <div class="carousel-caption text-start">
                <h1 style="color: black;">Пианино</h1>
                <p style="color: black;">Лучшие пианино в мире.</p>
                <p><a class="btn btn-lg btn-primary" href="#" style="color: black; background-color: white;">Подробнее</a></p>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <img src="images/5.jpeg" alt="" class="d-block w-100 h-100">
            <div class="container">
              <div class="carousel-caption">
                <h1 style="color: black;">Электро-Гитара.</h1>
                <p style="color: black;">Лучшая гитара в мире.</p>
                <p><a class="btn btn-lg btn-primary" href="#" style="color: black; background-color: white;">Подробнее</a></p>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <img src="images/7.png" alt="" class="d-block w-100 h-100">
            <div class="container">
              <div class="carousel-caption text-end">
                <h1 style="color: black;">Фортепиано.</h1>
                <p style="color: black;">Лучшее Фортепиано в мире.</p>
                <p><a class="btn btn-lg btn-primary" href="#" style="color: black; background-color: white;">Подробнее</a></p>
              </div>
            </div>
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
      
      


      <div class="jumbotron">
        <div class="container text-center">
          <h1>Добро пожаловать в Music House!</h1>
          <p>Мы предлагаем широкий выбор музыкальных услуг для всех ваших потребностей.</p>
          <a class="btn btn-primary btn-lg" href="about/index.php" role="button">Узнать больше</a>
        </div>
      </div>

      <div class="container">
        <div class="row">
          <div class="col-md-3">
            <div class="card h-100">
              <img src="images/7.png" class="card-img-top" alt="Instrument 1">
              <div class="card-body">
                <h5 class="card-title">Сентизатор</h5>
                <p class="card-text">Хороший Сентизатор</p>
                <a href="#" class="btn btn-primary" style="color: black; background-color: white;">Купить</a>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card h-100">
              <img src="images/2.jpeg" class="card-img-top" alt="Instrument 2">
              <div class="card-body">
                <h5 class="card-title">Пианино</h5>
                <p class="card-text">Для профессионалов</p>
                <a href="#" class="btn btn-primary" style="color: black; background-color: white;">Купить</a>
              </div>
            </div>
          </div>
          <!-- Добавьте еще блоки продажи инструментов здесь -->
          <!-- Пример блока продажи инструмента 3 -->
          <div class="col-md-3">
            <div class="card h-100">
              <img src="images/5.jpeg" class="card-img-top" alt="Instrument 3">
              <div class="card-body">
                <h5 class="card-title">Электро-Гитара</h5>
                <p class="card-text">Электрическая гитара</p>
                <a href="#" class="btn btn-primary" style="color: black; background-color: white;">Купить</a>
              </div>
            </div>
          </div>
          <!-- Пример блока продажи инструмента 4 -->
          <div class="col-md-3">
            <div class="card h-100">
              <img src="images/6.jpeg" class="card-img-top" alt="Instrument 4">
              <div class="card-body">
                <h5 class="card-title">Гитара</h5>
                <p class="card-text">Музыка от души</p>
                <a href="#" class="btn btn-primary" style="color: black; background-color: white;">Купить</a>
              </div>
            </div>
          </div>
         
        </div>
      </div>
      <footer class="footer">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <h4>Контакты</h4>
              <p>Номер телефона: 123-456-7890</p>
              <p>Email: info@example.com</p>
            </div>
            <div class="col-md-6">
              <h4>Местоположение</h4>
              <img src="images/map.jpg" alt="Местоположение" class="location-image">
            </div>
          </div>
        </div>
      </footer>
      
      <script src="js/bootstrap.js"></script>
</body>

</html>